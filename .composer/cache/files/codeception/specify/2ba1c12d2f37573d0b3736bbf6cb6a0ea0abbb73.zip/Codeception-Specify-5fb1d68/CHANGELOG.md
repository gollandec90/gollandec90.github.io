# Changelog

#### 0.4.2

* Testing exception messages by @chrismichaels84 https://github.com/Codeception/Specify#exceptions

#### 0.4.0

* Fixes cloning properties in examples. Issue #6 *2014-10-15*
* Added global and local specify configs, for disabling cloning properties and changing cloning methods *2014-10-15*


#### 0.3.6 03/22/2014

* Cloning unclonnable items


#### 0.3.5 03/22/2014

* Updated to DeepCopy 1.1.0


#### 0.3.4 02/23/2014

* Added DeepCopy library to save/restore objects between specs
* Robo file for releases
