<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Welcome!</title>
</head>
<body>
    <form method="POST" action="/form/form_with_buttons">
        <input type="text" name="test">
        <button type="button" name="button1" value="first">A Button</button>
        <input type="button" name="button2" value="second">
        <input type="submit" name="button3" value="third">
        <button type="submit" name="button4" value="fourth">A Submit Button</button>
    </form>
</body>
</html>