<html>
<head>
    <meta http-equiv="refresh" content="9; url=/info" />
</head>
<body>
    <h1>Meta redirect</h1>
</body>
</html>